/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.shiwa.repository.toolkit.wfengine;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author xp
 */
@Entity
@Table(name = "workflow_engine")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "WorkflowEngine.listByName", query = "SELECT we FROM WorkflowEngine we"),
    @NamedQuery(name = "WorkflowEngine.findAll", query = "SELECT w FROM WorkflowEngine w"),
    @NamedQuery(name = "WorkflowEngine.findByIdWE", query = "SELECT w FROM WorkflowEngine w WHERE w.idWE = :idWE"),
    @NamedQuery(name = "WorkflowEngine.findByNameWE", query = "SELECT w FROM WorkflowEngine w WHERE w.nameWE = :nameWE"),
    @NamedQuery(name = "WorkflowEngine.findByVersion", query = "SELECT w FROM WorkflowEngine w WHERE w.version = :version"),
    @NamedQuery(name = "WorkflowEngine.findByDescription", query = "SELECT w FROM WorkflowEngine w WHERE w.description = :description")})
public class WorkflowEngine implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idWE")
    private Integer idWE;
    @Size(max = 50)
    @Column(name = "nameWE")
    private String nameWE;
    @Size(max = 50)
    @Column(name = "version")
    private String version;
    @Size(max = 5000)
    @Column(name = "description")
    private String description;
    @JoinTable(name = "workflow_engine_files", joinColumns = {
        @JoinColumn(name = "idWE", referencedColumnName = "idWE")}, inverseJoinColumns = {
        @JoinColumn(name = "idWEFile", referencedColumnName = "idWEFile")})
    @ManyToMany(cascade = CascadeType.REMOVE)
    private Collection<WEUploadedFile> uploadedFileCollection;
    @OneToMany(cascade = CascadeType.REMOVE, mappedBy = "idWE", orphanRemoval = true)
    private Collection<WEImplementation> weImplementationCollection;

    public WorkflowEngine() {
    }
    
    private WorkflowEngine( String _name, String _version, String _description  )
    {
	this.nameWE = _name;
	this.version = _version;
	this.description = _description;
    }
    
    public static WorkflowEngine WorkflowEngineFactory
	( String _name, String _version, String _description)
	throws WEBuildingException
    {
	if ( _name.length() < 3 || _name.length() > 50)
	    throw new WEBuildingException( "name", _name );
        if ( _version.length() < 1 || _version.length() > 50 )
            throw new WEBuildingException( "version", _version );
        if ( _description.length() > 5000 )
            throw new WEBuildingException( "description", _description );

	return new WorkflowEngine( _name, _version, _description );
    }
    

    public WorkflowEngine(Integer idWE) {
        this.idWE = idWE;
    }

    public Integer getIdWE() {
        return idWE;
    }

    public void setIdWE(Integer idWE) {
        this.idWE = idWE;
    }

    public String getNameWE() {
        return nameWE;
    }

    public void setNameWE(String nameWE) {
        this.nameWE = nameWE;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @XmlTransient
    public Collection<WEUploadedFile> getUploadedFileCollection() {
        return uploadedFileCollection;
    }

    public void setUploadedFileCollection(Collection<WEUploadedFile> uploadedFileCollection) {
        this.uploadedFileCollection = uploadedFileCollection;
    }

    @XmlTransient
    public Collection<WEImplementation> getWeImplementationCollection() {
        return weImplementationCollection;
    }

    public void setWeImplementationCollection(Collection<WEImplementation> weImplementationCollection) {
        this.weImplementationCollection = weImplementationCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idWE != null ? idWE.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof WorkflowEngine)) {
            return false;
        }
        WorkflowEngine other = (WorkflowEngine) object;
        if ((this.idWE == null && other.idWE != null) || (this.idWE != null && !this.idWE.equals(other.idWE))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "org.shiwa.repository.toolkit.wfengine.WorkflowEngine[ idWE=" + idWE + " ]";
    }
    
}
